### Available Tags:

| Tag | Description |
|:--:|:--:|
|`{ppscore.rank}`|Rank of the player|
|`{ppscore.suffix}`|Suffix of the player|
|`{ppscore.perfix}`|Prefix of the player|